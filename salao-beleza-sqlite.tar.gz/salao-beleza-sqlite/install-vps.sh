#!/bin/bash

echo "🚀 Instalação do Sistema de Salão - SQLite"

# Instalar dependências Node.js
npm ci

# Aplicar migrações SQLite
npx drizzle-kit push --config=drizzle.sqlite.config.ts

# Inicializar base de dados
node init-sqlite-db.js

# Build da aplicação
npm run build

echo "✅ Instalação concluída!"
echo "🌐 Para iniciar: pm2 start start-sqlite.js --name salao-beleza"
